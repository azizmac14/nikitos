There are some notes and scripts _for development purpose only_

<figure>
    <img alt="There must be a funny running jumping gopher" src="https://github.com/egonelbre/gophers/raw/master/.thumb/animation/2bit-sprite/demo.gif">
    <figcaption>Kudos to <a href="https://github.com/egonelbre/gophers">egonelbre</a></figcaption>
</figure>